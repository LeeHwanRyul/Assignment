---
title: Release Notes
---

# Release Notes

```{eval-rst}
.. changelog::
    :github: https://github.com/Farama-Foundation/Minigrid/releases
    :pypi: https://pypi.org/project/minigrid/
    :changelog-url:
```
